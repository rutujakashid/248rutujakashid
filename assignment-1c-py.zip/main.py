a=int(input("enter value for a="))
b=int(input("enter value for b="))

addition=a+b
print(a,"+",b,"=",addition)

subtraction=a-b
print(a,"-",b,"=",subtraction)

multiplication=a*b
print(a,"*",b,"=",multiplication)